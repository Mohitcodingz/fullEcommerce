
const user = require('../model/user');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const sendEmail = require('../utils/sendEmail');
require('dotenv').config();


const generateToken = (id) => {
    return jwt.sign({ id }, process.env.JWT_SECRET, { expiresIn: '30h' })
}
async function registerUser(req, res) {
    try {
        const { name, email, password } = req.body;
        const existingUser = await user.findOne({ email });
        if (existingUser?.verified) {
            return res.status(400).json({ message: 'User already exists' });
        }
        const isNewUser = !existingUser;
        const newUser = existingUser || new user({
            name,
            email,
            password: bcrypt.hashSync(password, 8)
        });
        if (isNewUser) await newUser.save();
        if (newUser) {
            const otp = Math.floor(100000 + Math.random() * 900000);
            const otpExpires = new Date(Date.now() + 5 * 60 * 1000);
            const hashedOtp = bcrypt.hashSync(otp.toString(), 6);
            newUser.otp = hashedOtp;
            newUser.otpExpires = otpExpires;
            await newUser.save();
            const message = `Welcome ${newUser.name}! Your OTP for email verification is: ${otp}`;
            try {
                await sendEmail(email, 'Email Verification', message);
            } catch (emailError) {
                if (isNewUser) await newUser.deleteOne();
                console.error('Registration email delivery failed:', emailError.code || emailError.message);
                return res.status(503).json({
                    message: 'Could not send the verification email.'
                });
            }
            // DO NOT return token here - user must verify OTP first
            res.status(isNewUser ? 201 : 200).json({
                _id: newUser._id,
                name: newUser.name,
                email: newUser.email,
                message: isNewUser
                    ? 'User registered successfully. Please check your email for verification OTP.'
                    : 'Verification email sent. Please check your inbox.'
            });
        } else {
            res.status(400).json({ message: 'Invalid user data' });
        }
    } catch (error) {
        res.status(500).json({ message: 'Server error', error: error.message });
    }
}

async function verifyOtp(req, res) {
    try {
        const { email, otp } = req.body;
        const userEmail = await user.findOne({ email: email });
        if (!userEmail) {
            return res.status(404).json({ message: 'User not found' });
        }
        
        // Check if OTP is expired
        if (new Date() > userEmail.otpExpires) {
            return res.status(400).json({ message: 'OTP has expired. Please register again.' });
        }
        
        const compareOtp = bcrypt.compareSync(otp.toString(), userEmail.otp);
        if (compareOtp) {
            userEmail.verified = true;
            userEmail.otp = null;
            userEmail.otpExpires = null;
            await userEmail.save();
            
            // Now issue token after verification
            res.status(200).json({
                message: 'OTP verified successfully',
                _id: userEmail._id,
                name: userEmail.name,
                email: userEmail.email,
                role: userEmail.role,
                token: generateToken(userEmail._id)
            });
        } else {
            res.status(400).json({ message: 'Invalid OTP' });
        }
    } catch (error) {
        res.status(500).json({
            message: 'Error occurred',
            error: error.message
        });
    }
}
// checking if the users exits -> store in hashed password -> saving the new userin the database -> generating a jwt token  while sending welcome email to the (token function , sendEmail fucntion which is using nodemailer.)
async function loginUser(req, res) {
    try {
        const { email, password } = req.body;
        const existingUser = await user.findOne({ email });
        if (!existingUser) {
            return res.status(400).json({ message: 'Invalid email or password' });
        }
        else {
            const isPasswordValid = bcrypt.compareSync(password, existingUser.password);
            if (isPasswordValid) {
                res.status(200).json({
                    _id: existingUser._id,
                    name: existingUser.name,
                    email: existingUser.email,
                    role: existingUser.role,
                    token: generateToken(existingUser._id)
                });
            } else {
                res.status(400).json({ message: 'Invalid email or password' });
            }
        }
    }
    catch (error) {
        console.log('Error during login:', error);
        res.status(500).json({ message: 'Server error', error: error.message });
    }
}

async function getUser(req, res) {
    try {
        const newUser = await user.find({}).select('-password');
        res.json(newUser);
    }
    catch (error) {
        res.status(500).json({ message: 'Server error', error: error.message });
    }
}

module.exports = { registerUser, loginUser, getUser ,verifyOtp};
