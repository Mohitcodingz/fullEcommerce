const cashfree = require('../config/cashfree')
const order = require('../model/order')
async function createOrder(req, res) {
    try {
        const orderId = await order.findOne({ _id: req.params.id, user: req.user.id })
        if (!orderId) {
            return res.status(400).json({ message: 'The orderId is not found in Database' })
        }
        const amount = orderId.amount
        const cashfreeOrder = {
            order_id: `order_${Date.now()}`,
            order_amount: amount,
            order_currency: 'INR',
            customer_details: {
                customer_id: req.user._id.toString(),
                customer_phone: req.user.phone
            }
        };
        const response = await cashfree.PGCreateOrder(cashfreeOrder);
        
        // ✅ VALIDATE response before accessing properties
        if (!response || !response.data || !response.data.order_id || !response.data.payment_session_id) {
            console.error('CashFree API returned invalid response:', JSON.stringify(response));
            return res.status(500).json({ 
                message: 'Failed to create payment order: invalid gateway response',
                debug: response ? JSON.stringify(response) : 'No response from CashFree'
            })
        }
        
        // ✅ Fixed typo: staus → status
        return res.status(200).json({
            message: 'CashFree payment order created successfully',
            order_id: response.data.order_id,
            payment_session_id: response.data.payment_session_id
        })
    }
    catch (error) {
        console.error('CashFree Error creating order:', error.message, error.response?.data)
        res.status(500).json({ 
            message: 'Error occurred while creating payment order',
            error: process.env.NODE_ENV === 'development' ? error.message : undefined
        })
    }
}
async function verifyPayment(req, res) {
    try {
        const { order_id } = req.body;
        if (!order_id) {
            return res.status(400).json({
                message: 'CashFree OrderId is required'
            })
        }
        
        // ✅ Call CashFree API to fetch payment status
        const response = await cashfree.PGOrderFetchPayment(order_id);
        
        // ✅ Validate response exists
        if (!response || !response.data) {
            console.error('CashFree API returned invalid response:', response);
            return res.status(500).json({
                message: 'Failed to fetch payment status from gateway',
                debug: response ? JSON.stringify(response) : 'No response from CashFree'
            })
        }
        
        const payments = response.data;
        
        // ✅ Fixed syntax: correct find() syntax
        const successfulPayment = payments.find((x) => x.status === 'success');
        
        if (!successfulPayment) {
            return res.status(400).json({
                message: "Payment is not successful",
                payments
            })
        }
        
        // ✅ Update order status in MongoDB
        const updatedOrder = await order.findOneAndUpdate(
            { _id: req.body.orderId },  // Update with order ID from request
            { 
                status: 'paid',
                paymentId: successfulPayment.cf_payment_id || successfulPayment.id
            },
            { new: true }
        );
        
        return res.status(200).json({
            message: 'Payment verified successfully',
            successfulPayment,
            orderUpdated: !!updatedOrder
        })
    }
    catch (error) {
        console.error('Error verifying payment:', error.message)
        return res.status(500).json({
            message: 'Error occurred while verifying payment',
            error: process.env.NODE_ENV === 'development' ? error.message : undefined
        })
    }
}
module.exports = { createOrder, verifyPayment }
