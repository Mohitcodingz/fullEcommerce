const { Resend } = require('resend');
require('dotenv').config();

const sendEmail = async (to, subject, text) => {
    const { RESEND_API_KEY, SENDER_EMAIL } = process.env;
    
    if (!RESEND_API_KEY || !SENDER_EMAIL) {
        throw new Error('Email is not configured. Set RESEND_API_KEY and SENDER_EMAIL in backend/.env.');
    }

    const resend = new Resend(RESEND_API_KEY);
    
    const info = await resend.emails.send({
        from: SENDER_EMAIL,
        to,
        subject,
        text
    });
    
    console.log('Email sent successfully:', info.id);
    return info;
}

module.exports = sendEmail;
