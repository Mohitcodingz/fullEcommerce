const mongoose = require('mongoose');
const productSchema = new mongoose.Schema({
    name: { type: String, required: true },
    description: { type: String, required: true },
    price: { type: Number, required: true },  
    category: { type: String, required: true },
    imageUrl: { type: String, required: true },
    stock: { type: Number, required: true },    
    createdAt: { type: Date, default: Date.now },
    ratings: { type: Number, default: 0} ,
    numReviews: { type: Number, default: 0 },
});
const productModel = mongoose.model('Product', productSchema);
module.exports  =  productModel;