const { Cashfree, CFEnvironment } = require('cashfree-pg');
require('dotenv').config();
const cashfree = new Cashfree({
    cashfree_Env: CFEnvironment.SANDBOX,
    api_key: process.env.CASHFREE_API_KEY,        // ✅ CORRECT
    api_secret: process.env.CASHFREE_API_SECRET   // ✅ CORRECT
})
module.exports = cashfree
